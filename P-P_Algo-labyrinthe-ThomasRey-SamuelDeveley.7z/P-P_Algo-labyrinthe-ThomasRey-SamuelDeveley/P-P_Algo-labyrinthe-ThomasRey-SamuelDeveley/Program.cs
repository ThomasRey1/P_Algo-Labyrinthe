﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace P_P_Algo_labyrinthe_ThomasRey_SamuelDeveley
{
    class Program
    {
        const int LABYRINTHELENGTHX = 140,       //longueur x du labyrinthe
                 LABYRINTHELENGTHY = 100;        //longueur y du labyrinthe
                                                
        static int autoPositionX = 4,           //position x dans la console
                    autoPositionY = 3,          //position y dans la console
                    autoTabX = 0,               //position x dans le tableau bi-dimensionnel
                    autoTabY = 0;               //position y dans le tableau bi-dimensionnel

        static bool isFirstLoop = true;         //déterminer si c'est la première boucle (éviter l'exeption : stack empty, lors du 1er tour)

        static Random r = new Random();                                                            //nouveau random                                                                                            
        static Box[,] tabBox = new Box[LABYRINTHELENGTHX, LABYRINTHELENGTHY];                      //labyrinthe bi-dimensionnel contenant les cases du labyrinthe                                                                                            
        static Stack stackBox = new Stack(LABYRINTHELENGTHX * LABYRINTHELENGTHY + 1);              //création de la stack (lifo) pour la génération du labyrinthe                                                                                        
        static Stack autoSolveStackBox = new Stack(LABYRINTHELENGTHX * LABYRINTHELENGTHY + 1);     //création de la stack (lifo) pour l'auto solving du labyrinthe 
                                                                                            
                                                           

        static void Main()
        {
           
            Console.SetBufferSize(2500, 2500);

            GenerateBidimensionalArrayBox();

            CreateLabyrinthe(tabBox[0, 0], "North");
        }

        /// <summary>
        /// générer un tableau bi-dimensionnel de case
        /// </summary>
        public static void GenerateBidimensionalArrayBox()
        {
            for (int y = 0; y < LABYRINTHELENGTHY; y++)
            {
                for (int x = 0; x < LABYRINTHELENGTHX; x++)
                {
                    //création des cases
                    Box box = new Box(x + "," + y, x, y);
                    tabBox[x, y] = box;

                    //ouvrerture du mur sud pour la dernière case
                    if (x == LABYRINTHELENGTHX - 1 && y == LABYRINTHELENGTHY - 1)
                    {
                        box.South = false;
                    }
                }
            }
        }

        /// <summary>
        /// génération du labyrinthe
        /// </summary>
        /// <param name="currentBox">case actuel sur laquel se trouve le programme</param>
        /// <param name="cardinalPoint">cardinalité permettant de déterminer quel sera le prochain mur à ouvrir</param>
        public static void CreateLabyrinthe(Box currentBox, string cardinalPoint)
        { 
            List<Box> listBoxTemp = new List<Box>();     //liste de box temporaire permettant de stocker
            Box tempBox = new Box();                     //box temporaire permettant de stocker la case tirée au sort
            
            //déterminer le cas de base (stack.IsEmpty) 
            if (!stackBox.IsEmpty() || isFirstLoop)
            {
                isFirstLoop = false;

                //check et push de la case si dans la stack si celle-ci n'est pas checkée
                if (!currentBox.IsChecked)
                {
                    stackBox.Push(currentBox);

                    currentBox.IsChecked = true;
                }

                //ouvertur du mur sur le côté donné
                switch (cardinalPoint)
                {
                    case "North":
                        currentBox.North = false;
                        break;

                    case "East":
                        currentBox.East = false;
                        break;

                    case "South":
                        currentBox.South = false;
                        break;

                    case "West":
                        currentBox.West = false;
                        break;
                    case "":
                        break;
                }


                //check la/les prochaine case libre à partir de cette position et ajout des cases libre dans la liste temporaire

                //est
                if (currentBox.LocationX + 1 < LABYRINTHELENGTHX && !tabBox[currentBox.LocationX + 1, currentBox.LocationY].IsChecked)
                {
                    listBoxTemp.Add(tabBox[currentBox.LocationX + 1, currentBox.LocationY]);
                }

                //ouest
                if (currentBox.LocationX - 1 >= 0 && !tabBox[currentBox.LocationX - 1, currentBox.LocationY].IsChecked)
                {
                    listBoxTemp.Add(tabBox[currentBox.LocationX - 1, currentBox.LocationY]);
                }

                //nord
                if (currentBox.LocationY - 1 >= 0 && !tabBox[currentBox.LocationX, currentBox.LocationY - 1].IsChecked)
                {
                    listBoxTemp.Add(tabBox[currentBox.LocationX, currentBox.LocationY - 1]);
                }

                //sud
                if (currentBox.LocationY + 1 < LABYRINTHELENGTHY && !tabBox[currentBox.LocationX, currentBox.LocationY + 1].IsChecked)
                {
                    listBoxTemp.Add(tabBox[currentBox.LocationX, currentBox.LocationY + 1]);
                }


                

                //si la liste est vide alors dépiler
                if (listBoxTemp.Count != 0)
                {
                    while (listBoxTemp.Count != 0)
                    {
                        //si il y a une/des cases libre alors tirer un random entre toutes ces cases
                        int randomResult = r.Next(0, listBoxTemp.Count);

                        //Ouvrir le mur en direction de la case libre et relancer la méthode avec la prochaine case en argument et le prochain mur à ouvrir
                        //prochaine case direction sud
                        if (listBoxTemp[randomResult].LocationX == currentBox.LocationX && listBoxTemp[randomResult].LocationY == currentBox.LocationY + 1)
                        {
                            
                            currentBox.South = false;
                            tempBox = listBoxTemp[randomResult];
                            listBoxTemp.Remove(listBoxTemp[randomResult]);
                            CreateLabyrinthe(tempBox, "North");
                        }
                        //prochaine case direction nord
                        else if (listBoxTemp[randomResult].LocationX == currentBox.LocationX && listBoxTemp[randomResult].LocationY == currentBox.LocationY - 1)
                        {
                            
                            currentBox.North = false;
                            tempBox = listBoxTemp[randomResult];
                            listBoxTemp.Remove(listBoxTemp[randomResult]);
                            CreateLabyrinthe(tempBox, "South");
                        }
                        //prochaine case direction est
                        else if (listBoxTemp[randomResult].LocationX == currentBox.LocationX + 1 && listBoxTemp[randomResult].LocationY == currentBox.LocationY)
                        {
                            
                            currentBox.East = false;
                            tempBox = listBoxTemp[randomResult];
                            listBoxTemp.Remove(listBoxTemp[randomResult]);
                            CreateLabyrinthe(tempBox, "West");
                        }
                        //prochaine case direction ouest
                        else if (listBoxTemp[randomResult].LocationX == currentBox.LocationX - 1 && listBoxTemp[randomResult].LocationY == currentBox.LocationY)
                        {
                            
                            currentBox.West = false;
                            tempBox = listBoxTemp[randomResult];
                            listBoxTemp.Remove(listBoxTemp[randomResult]);
                            CreateLabyrinthe(tempBox, "East");
                        }
                    }
                }
                else
                {
                    //si il y a pas de case libre alors dépiler 
                    stackBox.Pop();
                    CreateLabyrinthe(stackBox.Top(), "");
                }

            }
            else
            {
                //reinitialisation à true pour 
                isFirstLoop = true;

                //lorsque le labyrinthe à fini de se générer alors afficher le labyrinthe dans la console
                DisplayLabyrinthe();
                
            }
        }

        /// <summary>
        /// afficher le labyrinthe dans la console
        /// </summary>
        public static void DisplayLabyrinthe()
        {
            int positionX = 2;     //position x dans la console
            int positionY = 2;     //position y dans la console

            //parcourir toutes les cases du tableau bi-dimensionnel et affichage du pattern adéquat dans la console
            for (int y = 0; y < LABYRINTHELENGTHY; y++)
            {
                for (int x = 0; x < LABYRINTHELENGTHX; x++)
                {
                    //les différentes possibilité de pattern
                    if (!tabBox[x, y].East && !tabBox[x, y].North && !tabBox[x, y].West && !tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("     ");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█   █");
                    }
                    else if (!tabBox[x, y].East && !tabBox[x, y].North && !tabBox[x, y].West && tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("     ");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█████");
                    }
                    else if (!tabBox[x, y].East && !tabBox[x, y].North && tabBox[x, y].West && !tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("█    ");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█   █");
                    }
                    else if (!tabBox[x, y].East && !tabBox[x, y].North && tabBox[x, y].West && tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("█    ");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█████");
                    }
                    else if (!tabBox[x, y].East && tabBox[x, y].North && !tabBox[x, y].West && !tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█████");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("     ");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█   █");
                    }
                    else if (!tabBox[x, y].East && tabBox[x, y].North && !tabBox[x, y].West && tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█████");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("     ");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█████");
                    }
                    else if (!tabBox[x, y].East && tabBox[x, y].North && tabBox[x, y].West && !tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█████");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("█    ");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█   █");
                    }
                    else if (!tabBox[x, y].East && tabBox[x, y].North && tabBox[x, y].West && tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█████");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("█    ");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█████");
                    }
                    else if (tabBox[x, y].East && !tabBox[x, y].North && !tabBox[x, y].West && !tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("    █");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█   █");
                    }
                    else if (tabBox[x, y].East && !tabBox[x, y].North && !tabBox[x, y].West && tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("    █");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█████");
                    }
                    else if (tabBox[x, y].East && !tabBox[x, y].North && tabBox[x, y].West && !tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█   █");
                    }
                    else if (tabBox[x, y].East && !tabBox[x, y].North && tabBox[x, y].West && tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█████");
                    }
                    else if (tabBox[x, y].East && tabBox[x, y].North && !tabBox[x, y].West && !tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█████");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("    █");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█   █");
                    }
                    else if (tabBox[x, y].East && tabBox[x, y].North && !tabBox[x, y].West && tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█████");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("    █");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█████");
                    }
                    else if (tabBox[x, y].East && tabBox[x, y].North && tabBox[x, y].West && !tabBox[x, y].South)
                    {
                        Console.SetCursorPosition(positionX, positionY);
                        Console.Write("█████");
                        Console.SetCursorPosition(positionX, positionY + 1);
                        Console.Write("█   █");
                        Console.SetCursorPosition(positionX, positionY + 2);
                        Console.Write("█   █");
                    }
                    //incrément des positions
                    positionX += 4;
                }
                positionX = 2;
                positionY += 2;
            }
            //lancement des résollutions du labyrinthe
            // SolveLabyrintheWithPlayer();
            SolveLabyrintheAuto(tabBox[0,0]);
            
            Console.ReadLine();
        }

        /// <summary>
        /// résolution du labyrinthe par le joueur
        /// </summary>
        public static void SolveLabyrintheWithPlayer()
        {

            int tabX = 0,               //position x dans le tableau bi-dimensionnel
                tabY = 0,               //position y dans le tableau bi-dimensionnel
                playerPositionX = 0,    //position x du joueur dans la console
                playerPositionY = 0;    //position x du joueur dans la console

            char player = '♦';          //représente le player

            //placement du player
            Console.SetCursorPosition(playerPositionX += 4, playerPositionY+=3);
            Console.Write(player);

            do
            {
                if(tabX != LABYRINTHELENGTHX && tabY != LABYRINTHELENGTHY)
                {
                    //récupèrer la touche enfoncée et ne l'inscrit pas dans la console           
                    ConsoleKey key = Console.ReadKey(true).Key;


                    switch (key)
                    {
                        case ConsoleKey.LeftArrow:
                            //déplacement du joueur contre la gauche
                            if (!tabBox[tabX, tabY].West)
                            {
                                //faire avancer le player jusqu'a la prochaine intersection  
                                do
                                {
                                    Console.SetCursorPosition(playerPositionX, playerPositionY);
                                    Console.Write(" ");

                                    Console.SetCursorPosition(playerPositionX -= 4, playerPositionY);
                                    Console.Write(player);
                                    tabX--;
                                }
                                while (tabBox[tabX, tabY].North && tabBox[tabX, tabY].South && !tabBox[tabX, tabY].West);
                            }
                            break;

                        case ConsoleKey.RightArrow:
                            //déplacement du joueur contre la droite
                            if (!tabBox[tabX, tabY].East)
                            {
                                //faire avancer le player jusqu'a la prochaine intersection  
                                do
                                {
                                    
                                    Console.SetCursorPosition(playerPositionX, playerPositionY);
                                    Console.Write(" ");

                                    Console.SetCursorPosition(playerPositionX += 4, playerPositionY);
                                    Console.Write(player);
                                    tabX++;
                                }
                                while (tabBox[tabX, tabY].North && tabBox[tabX, tabY].South && !tabBox[tabX, tabY].East);
                            }
                            break;

                        case ConsoleKey.UpArrow:
                            //déplacement du joueur contre le haut
                            if (!tabBox[tabX, tabY].North)
                            {
                                //faire avancer le player jusqu'a la prochaine intersection  
                                do
                                {
                                    if(tabY != 0)
                                    {
                                        Console.SetCursorPosition(playerPositionX, playerPositionY);
                                        Console.Write(" ");

                                        Console.SetCursorPosition(playerPositionX, playerPositionY -= 2);
                                        Console.Write(player);
                                        tabY--;
                                    }
                                    else
                                    {
                                        break;
                                    }
                                    
                                }
                                while (tabBox[tabX, tabY].West && tabBox[tabX, tabY].East && !tabBox[tabX, tabY].North);
                            }
                            break;

                        case ConsoleKey.DownArrow:
                            //déplacement du joueur contre le bas
                            if (!tabBox[tabX, tabY].South)
                            {
                                
                                    do
                                    {
                                        //faire avancer le player jusqu'a la prochaine intersection si ce n'est pas la case de sortie  
                                        if (tabX != LABYRINTHELENGTHX - 1 || tabY != LABYRINTHELENGTHY - 1)
                                        {
                                            Console.SetCursorPosition(playerPositionX, playerPositionY);
                                            Console.Write(" ");

                                            Console.SetCursorPosition(playerPositionX, playerPositionY += 2);
                                            Console.Write(player);
                                            tabY++;
                                        }
                                        else
                                        {
                                            Console.SetCursorPosition(0, LABYRINTHELENGTHY + 10);
                                            Console.WriteLine("Vous avez trouvé la sortie !!");
                                            Console.Write("Relancer le programme (y/n) ? ");
                                            
                                            //relancer le programm si le player veut
                                            if (Console.ReadLine() == "y" || Console.ReadLine() == "Y")
                                            {
                                                Console.Clear();

                                                // lancement de l'exe
                                                System.Diagnostics.Process.Start(@"F:\AllProjet\C#\P-P_Algo-labyrinthe-ThomasRey-SamuelDeveley\P-P_Algo-labyrinthe-ThomasRey-SamuelDeveley\bin\Release\P-P_Algo-labyrinthe-ThomasRey-SamuelDeveley.exe");

                                                //ferme la fenêtre actuelle
                                                Environment.Exit(0);
                                            }

                                            break;
                                        }
                                    
                                    }
                                    while (tabBox[tabX, tabY].West && tabBox[tabX, tabY].East && !tabBox[tabX, tabY].South);
                                  
                            }
                            break;
                    }
                }                
            }
            while (Console.KeyAvailable == false);
        }

        /// <summary>
        /// résoudre le labyrinthe automatiquement
        /// </summary>
        /// <param name="currentBox"></param>
        public static void SolveLabyrintheAuto(Box currentBox)
        {         
            List<Box> tempListBox = new List<Box>();  //création d'une liste de box temporaire 
            
            int value = 0;                            //valeur jusqu'à où le programme peut display le chemin

            //déterminer le cas de base (stack.IsEmpty) 
            if (!autoSolveStackBox.IsEmpty() || isFirstLoop)
            {
                isFirstLoop = false;

                //check en true si la box n'a pas encors été checkée
                if (!currentBox.IsCheckedByAutoSolving)
                {
                    currentBox.IsCheckedByAutoSolving = true;
                    autoSolveStackBox.Push(currentBox);
                }
                 
                

                //check la/les prochaine case libre à partir de cette position et ajout des cases libre

                //est
                if (currentBox.LocationX + 1 < LABYRINTHELENGTHX && !tabBox[currentBox.LocationX + 1, currentBox.LocationY].IsCheckedByAutoSolving && !currentBox.East)
                {
                    tempListBox.Add(tabBox[currentBox.LocationX + 1, currentBox.LocationY]);
                }
                //ouest
                if (currentBox.LocationX - 1 >= 0 && !tabBox[currentBox.LocationX - 1, currentBox.LocationY].IsCheckedByAutoSolving && !currentBox.West)
                {
                    tempListBox.Add(tabBox[currentBox.LocationX - 1, currentBox.LocationY]);
                }
                //nord
                if (currentBox.LocationY - 1 >= 0 && !tabBox[currentBox.LocationX, currentBox.LocationY - 1].IsCheckedByAutoSolving && !currentBox.North)
                {
                    tempListBox.Add(tabBox[currentBox.LocationX, currentBox.LocationY - 1]);
                }
                //sud
                if (currentBox.LocationY + 1 < LABYRINTHELENGTHY && !tabBox[currentBox.LocationX, currentBox.LocationY + 1].IsCheckedByAutoSolving && !currentBox.South)
                {
                    tempListBox.Add(tabBox[currentBox.LocationX, currentBox.LocationY + 1]);
                }

                if (tempListBox.Count != 0)
                {

                    //si il y a une/des cases libre alors tirer un random entre toutes ces cases
                    int randomResult = r.Next(0, tempListBox.Count);

                    //Ouvrir le mur en direction de la case libre et relancer la méthode avec la prochaine case en argument et le prochain côté à ouvrir
                    if (tempListBox[randomResult].LocationX == currentBox.LocationX && tempListBox[randomResult].LocationY == currentBox.LocationY + 1)
                    {
                        //avancer le chemin direction sud
                        value = autoPositionY + 2;
                        for (int x = 0; autoPositionY < value; x++)
                        {
                           
                            DisplayColorPath(autoPositionX, autoPositionY, tempListBox[randomResult].IsCheckedByAutoSolving);
                            autoPositionY++;
                        }
                        autoTabY++;
                        SolveLabyrintheAuto(tempListBox[randomResult]);
                    }
                    else if (tempListBox[randomResult].LocationX == currentBox.LocationX && tempListBox[randomResult].LocationY == currentBox.LocationY - 1)
                    {
                        //next au nord
                        value = autoPositionY - 2;
                        for (int x = 0; autoPositionY > value; x++)
                        {
                           
                            DisplayColorPath(autoPositionX, autoPositionY, tempListBox[randomResult].IsCheckedByAutoSolving);
                            autoPositionY--;
                        }
                        autoTabY--;
                        SolveLabyrintheAuto(tempListBox[randomResult]);
                    }
                    else if (tempListBox[randomResult].LocationX == currentBox.LocationX + 1 && tempListBox[randomResult].LocationY == currentBox.LocationY)
                    {
                        //next a est
                        value = autoPositionX + 4;
                        for (int x = 0; autoPositionX < value; x++)
                        {
                            
                            DisplayColorPath(autoPositionX, autoPositionY, tempListBox[randomResult].IsCheckedByAutoSolving);
                            autoPositionX++;
                        }
                        autoTabX++;
                        SolveLabyrintheAuto(tempListBox[randomResult]);
                    }
                    else if (tempListBox[randomResult].LocationX == currentBox.LocationX - 1 && tempListBox[randomResult].LocationY == currentBox.LocationY)
                    {
                        //next a ouest
                        value = autoPositionX - 4;
                        for (int x = 0; autoPositionX > value; x++)
                        {
                           
                            DisplayColorPath(autoPositionX, autoPositionY, tempListBox[randomResult].IsCheckedByAutoSolving);
                            autoPositionX--;
                        }
                        autoTabX--;
                        SolveLabyrintheAuto(tempListBox[randomResult]);
                    }

                }
                else
                {
                    //si il y a pas de case libre alors dépiler si il n'y a pas de case de libre
                    if (autoTabX != LABYRINTHELENGTHX - 1 || autoTabY != LABYRINTHELENGTHY - 1)
                    {
                        autoSolveStackBox.Pop();
                        CompairCurrentBoxAndLast(currentBox, autoSolveStackBox.Top());
                        SolveLabyrintheAuto(autoSolveStackBox.Top());
                    }
                    else
                    {

                    }
                    
                }
            }

            
        }

        public static void DisplayColorPath(int x, int y, bool isChecked)
        {
            if (isChecked)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.SetCursorPosition(x, y);
                Console.WriteLine("█");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.SetCursorPosition(x, y);
                Console.WriteLine("█");
            }
        }
        public static void CompairCurrentBoxAndLast(Box current, Box last)
        {
            int value = 0;

            if(current.LocationX == last.LocationX && current.LocationY - 1 == last.LocationY)
            {
                //last nord
                value = autoPositionY - 2;
                for (int x = 0; autoPositionY > value; x++)
                {
                    DisplayColorPath(autoPositionX, autoPositionY, current.IsCheckedByAutoSolving);
                    autoPositionY--;
                }
                autoTabY--;
            }
            if (current.LocationX == last.LocationX && current.LocationY + 1 == last.LocationY)
            {
                //last sud
                value = autoPositionY + 2;
                for (int x = 0; autoPositionY < value; x++)
                {
                    DisplayColorPath(autoPositionX, autoPositionY, current.IsCheckedByAutoSolving);
                    autoPositionY++;
                }
                autoTabY++;
            }
            if (current.LocationX + 1 == last.LocationX && current.LocationY == last.LocationY)
            {
                //last est
                value = autoPositionX + 4;
                for (int x = 0; autoPositionX < value; x++)
                {
                    DisplayColorPath(autoPositionX, autoPositionY, current.IsCheckedByAutoSolving);
                    autoPositionX++;
                }
                autoTabX++;
            }
            if (current.LocationX - 1 == last.LocationX && current.LocationY == last.LocationY)
            {
                //last ouest
                value = autoPositionX - 4;
                for (int x = 0; autoPositionX > value; x++)
                {
                    DisplayColorPath(autoPositionX, autoPositionY, current.IsCheckedByAutoSolving);
                    autoPositionX--;
                }
                autoTabX--;
            }
        }
    }
}
